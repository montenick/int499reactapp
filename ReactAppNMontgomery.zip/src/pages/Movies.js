import React from 'react';

function Movies() {
  return <h1>Movies Page</h1>;
}

export default Movies;

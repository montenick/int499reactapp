import React from 'react';

function StreamList() {
  return <h2>StreamList Page</h2>;
}

export default StreamList;
